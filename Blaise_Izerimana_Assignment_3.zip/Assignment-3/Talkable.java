public interface Talkable {
    String getSpeaker();
    String getAbstractText();
}