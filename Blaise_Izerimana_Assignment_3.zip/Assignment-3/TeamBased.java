public interface TeamBased {
    String[] getTeams();
    String getDetails();
}
