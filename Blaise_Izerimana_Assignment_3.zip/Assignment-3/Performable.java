
public interface Performable {
  String[] getPerformers();
}
