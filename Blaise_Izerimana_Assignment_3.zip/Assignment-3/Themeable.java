public interface Themeable {
    String getTheme();
}
